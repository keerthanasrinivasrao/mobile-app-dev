package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    var clickCount=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val clickCountDisplayView = findViewById<TextView>(R.id.clickCountView)
        val clickMeButton = findViewById<TextView>(R.id.clickButton)
        val usernameTextInput = findViewById<TextInputLayout>(R.id.enterName)
        clickMeButton.setOnClickListener {

            val username=usernameTextInput.editText?.text?.toString();
            val maskedUserName= if(username.isNullOrEmpty()) "Somebody"
            else username
            clickCount++
            clickCountDisplayView.text = "$maskedUserName $clickCount times"

        }
    }
}